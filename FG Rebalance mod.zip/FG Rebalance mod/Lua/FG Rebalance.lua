--[[
FG Rebalance mod

]]

--==[Создание класса мода]==--

if not _G.FG_Rebalance_mod then
    _G.FG_Rebalance_mod = _G.FG_Rebalance_mod or {}
    FG_Rebalance_mod._path = ModPath
    FG_Rebalance_mod._data_path = SavePath .. "FGdata.txt"
    FG_Rebalance_mod._data = {} 
end

--==[Методы класса мода]==--

--Сохранение настроек
function FG_Rebalance_mod:Save()
	local file = io.open( self._data_path, "w+" )
	if file then
		file:write( json.encode( self._data ) )
		file:close()
	end
end
--Загрузка настроек
function FG_Rebalance_mod:Load()
	local file = io.open( self._data_path, "r" )
	if file then
		self._data = json.decode( file:read("*all") )
		file:close()
	end
end

FG_Rebalance_mod:Load()

--==[Меню настроек]==--
if FG_Rebalance_mod._data.fun_mode == nil then
	FG_Rebalance_mod._data.fun_mode = true
	FG_Rebalance_mod:Save()
end
--Локализация
Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_FG_Rebalance_mod", function( loc )
	loc:load_localization_file( FG_Rebalance_mod._path .. "Localization/ru.txt")
end)

--Создание меню настроек
Hooks:Add( "MenuManagerInitialize", "MenuManagerInitialize_FG_Rebalance_mod", function( menu_manager, nodes )
	MenuCallbackHandler.callback_toggle_fun_mode = function(self, item)
		FG_Rebalance_mod._data.fun_mode = (item:value() == "on" and true or false)
		FG_Rebalance_mod:Save()
    end
    
	MenuHelper:LoadFromJsonFile( FG_Rebalance_mod._path .. "Menu/Menu.json", FG_Rebalance_mod, FG_Rebalance_mod._data )
end )

--==[Баланс оружия]==--
if RequiredScript == "lib/tweak_data/weapontweakdata" then
    Hooks:PostHook(WeaponTweakData, "init", "weapontweakdata", function(self)

        --Saiga   
        self.saiga.stats.damage = 240
        self.saiga.can_shoot_through_shield = true
        self.saiga.AMMO_PICKUP = {7, 7}
        self.saiga.timers.unequip = 0.1
        self.saiga.timers.equip = 0.1
        
        --Fun mode
        if FG_Rebalance_mod._data.fun_mode == true then
            self.m134.CLIP_AMMO_MAX = 1000
            self.m134.NR_CLIPS_MAX = 2
            self.m134.AMMO_MAX = self.m134.CLIP_AMMO_MAX * self.m134.NR_CLIPS_MAX
            self.m134.AMMO_PICKUP = {100,100}
            self.m134.can_shoot_through_shield = true
            self.m134.stats.damage = 99999
            self.m134.stats.concealment = 50
            self.m134.timers = {
                reload_not_empty = 1,
                reload_empty = 1,
                unequip = 0.1,
                equip = 0.1
            }
        end
    end)
end

--==[Баланс дерева навыков]==--
if RequiredScript == "lib/tweak_data/skilltreetweakdata" then
    Hooks:PostHook(SkillTreeTweakData, "init", "FG_skilltreetweakdata", function(self, tweak_data)
	
        table.insert(self.default_upgrades, "player_health_damage_reduction_3")
    
        self.skills.frenzy[1].upgrades = {"player_max_health_reduction_1",
            "player_healing_reduction_2",
            "player_health_damage_reduction_3",
            "smoke_screen_grenade"
        }
        self.skills.frenzy[2].upgrades = {
            "player_healing_reduction_2", 
            "player_damage_dampener_close_contact_1"

--[[
        self.specializations[18][1].upgrades = {
            "smoke_screen_grenade"
        }
        self.specializations[18][3].upgrades = {
            "player_dodge_shot_gain"
        }
        self.specializations[18][5].upgrades = {
            "player_passive_dodge_chance_2", 
            "player_kill_change_regenerate_speed" 
        }
        self.specializations[18][7].upgrades = {
            "player_dodge_replenish_armor", 
            "player_damage_to_hot_1", 
            "player_damage_to_hot_extra_ticks"
        }
        self.specializations[18][9].upgrades = {
            "player_smoke_screen_ally_dodge_bonus", 
            "player_sicario_multiplier", 
            "weapon_passive_swap_speed_multiplier_1", 
            "akimbo_recoil_index_addend_4",
            "akimbo_extra_ammo_multiplier_3"
        }
]]
    end)
end

--==[Улучшение навыков]==--
if RequiredScript == "lib/tweak_data/upgradestweakdata" then
    Hooks:PostHook(UpgradesTweakData, "init", "FG_upgradestweakdata", function(self)
	
        self.values.player.health_damage_reduction = {
            0.9,
            0.75,
            0.3,
            0
        }
        self.definitions.player_health_damage_reduction_3 = {
            name_id = "menu_player_health_damage_reduction",
            category = "feature",
            upgrade = {
                value = 3,
                upgrade = "health_damage_reduction",
                category = "player"
            }
        }
    
    end)
end

--==[]==--

--==[]==--

--==[]==--

--==[]==--