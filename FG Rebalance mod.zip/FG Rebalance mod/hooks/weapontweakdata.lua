local old_init = WeaponTweakData.init

function WeaponTweakData:init(tweak_data)
    old_init(self, tweak_data)


--Saiga   
self.saiga.spread.standing = self.r870.spread.standing
self.saiga.spread.crouching = self.r870.spread.standing
self.saiga.spread.steelsight = self.r870.spread.standing
self.saiga.spread.moving_standing = self.r870.spread.moving_standing
self.saiga.spread.moving_crouching = self.r870.spread.moving_standing
self.saiga.spread.moving_steelsight = self.r870.spread.moving_standing
self.saiga.CLIP_AMMO_MAX = 8
self.saiga.AMMO_MAX = 72
self.saiga.stats.damage = 99999
self.saiga.stats.spread = 19
self.saiga.stats.recoil = 0
self.saiga.stats.suppression = 50
self.saiga.fire_mode_data.fire_rate = 0.120
self.saiga.can_shoot_through_shield = true
self.saiga.AMMO_PICKUP = {7, 7}
self.saiga.kick.standing = {1.9, 2, -0.2, 0.2}
self.saiga.kick.crouching = self.saiga.kick.standing
self.saiga.kick.steelsight = {1.5, 1.7, -0.2, 0.2}
self.saiga.timers = {
    reload_not_empty = 1,
    reload_empty = 1,
    unequip = 0.1,
    equip = 0.1
}


--Fun gun
self.m134.CLIP_AMMO_MAX = 1000
self.m134.NR_CLIPS_MAX = 2
self.m134.AMMO_MAX = self.m134.CLIP_AMMO_MAX * self.m134.NR_CLIPS_MAX
self.m134.AMMO_PICKUP = {100,100}
self.m134.can_shoot_through_shield = true
self.m134.stats = {
    zoom = 1,
    total_ammo_mod = 21,
    damage = 99999,
    alert_size = 8,
    spread = 9,
    spread_moving = 9,
    recoil = 7,
    value = 9,
    extra_ammo = 51,
    reload = 11,
    suppression = 4,
    concealment = 50
}
self.m134.timers = {
    reload_not_empty = 1,
    reload_empty = 1,
    unequip = 0.1,
    equip = 0.1
}
end