--[[
FG Rebalance mod
"updates": [
    		{
      		"identifier": "FG-Rebalance-mod-GitHub-Update",
      		"host": {
      	  		"meta": "https://raw.githubusercontent.com/Navatusein/FG-Rebalance-mod/master/meta.json",
        		"patchnotes": "https://github.com/Navatusein/FG-Rebalance-mod/commits/master",
        		"download": "https://github.com/Navatusein/FG-Rebalance-mod/raw/master/FG%20Rebalance%20mod.zip"
      			}
    		}
  	]
]]

--==[Создание класса мода]==--

if not _G.FG_Rebalance_mod then
    _G.FG_Rebalance_mod = _G.FG_Rebalance_mod or {}
    FG_Rebalance_mod._path = ModPath
    FG_Rebalance_mod._settings_path = SavePath .. "FGdata.txt"
    FG_Rebalance_mod._settings = {}
    FG_Rebalance_mod._settings["Fun_mode"] = false
    FG_Rebalance_mod._settings["Base_skill"] = 1
    FG_Rebalance_mod._settings["Perk_Deck"] = 1
    FG_Rebalance_mod.perks = {
        --Перк дек неко
        {
            name = "Neko perk",
            disc = ":D",
            upgrades = {
                "smoke_screen_grenade",
                "player_dodge_shot_gain",
                "player_passive_dodge_chance_2", 
                "player_kill_change_regenerate_speed",
                "player_dodge_replenish_armor", 
                "player_damage_to_hot_1", 
                "player_damage_to_hot_extra_ticks",
                "player_smoke_screen_ally_dodge_bonus", 
                "player_sicario_multiplier", 
                "weapon_passive_swap_speed_multiplier_1", 
                "akimbo_recoil_index_addend_4",
                "akimbo_extra_ammo_multiplier_3"
            }
        }
    }
end



--==[Методы класса мода]==--

--Сохранение настроек
function FG_Rebalance_mod:Save()
    SkillTreeTweakData:init()
	local file = io.open( self._settings_path, "w+" )
	if file then
		file:write( json.encode( self._settings ) )
		file:close()
	end
end
--Загрузка настроек
function FG_Rebalance_mod:Load()
	local file = io.open( self._settings_path, "r" )
	if file then
		self._settings = json.decode( file:read("*all") )
		file:close()
	end
end

function FG_Rebalance_mod:Add_to_table(table_in , table_out)
    for i, d in pairs(table_out)  do 
        table.insert(table_in, d)
    end
end

FG_Rebalance_mod:Load()


--==[Локализация]==--
Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_FG_Rebalance_mod", function( loc )
    loc:load_localization_file( FG_Rebalance_mod._path .. "Localization/ru.txt")
end)
   
--==[Меню настроек]==--
if RequiredScript == "lib/managers/menumanager" then
    Hooks:Add("MenuManagerInitialize", "MenuManagerInitialize_FG_Rebalance_mod", function(menu_manager)

        --События меню настроек

        MenuCallbackHandler.callback_multiple_choice_base = function(self, item)
            FG_Rebalance_mod._settings.Base_skill = item:value()
            FG_Rebalance_mod:Save()
        end

        MenuCallbackHandler.callback_toggle_fun_mode = function(self, item)
            FG_Rebalance_mod._settings.Fun_mode = (item:value() == "on" and true or false)
            FG_Rebalance_mod:Save()
        end

        MenuCallbackHandler.FG_menu_back = function(this, item)
            FG_Rebalance_mod:Save()
        end

        --Объявление меню настроек
        Hooks:Add("MenuManagerSetupCustomMenus", "MenuManagerSetupCustomMenus_FG_Rebalance_mod", function( menu_manager, nodes )
            MenuHelper:NewMenu( "FG_menu" )
        end)

        --Создание меню настроек
        Hooks:Add("MenuManagerBuildCustomMenus", "MenuManagerBuildCustomMenus_FG_Rebalance_mod", function( menu_manager, nodes )
            local parent_menu = "blt_options"
            local menu_id = "FG_menu"
            local menu_name = "FG_menu_title"
            local menu_desc = "FG_menu_desc"

            local data = {
                focus_changed_callback = nil,
                back_callback = "FG_menu_back",
                area_bg = nil,
            }
            nodes[menu_id] = MenuHelper:BuildMenu( menu_id, data )
            MenuHelper:AddMenuItem( nodes[parent_menu], menu_id, menu_name, menu_desc, nil )

        end)

        --Добавление елементов в меню настроек
        Hooks:Add("MenuManagerPopulateCustomMenus", "MenuManagerPopulateCustomMenus_FG_Rebalance_mod", function( menu_manager, nodes )
            
            local to_add = {
                "multiple_choice_base_skill_1" , 
                "multiple_choice_base_skill_2" ,
                "multiple_choice_base_skill_3" ,
                "multiple_choice_base_skill_4" ,
                "multiple_choice_base_skill_5" ,
                "multiple_choice_base_skill_6" ,
                "multiple_choice_base_skill_7" ,
                "multiple_choice_base_skill_8" ,
                "multiple_choice_base_skill_9" ,
                "multiple_choice_base_skill_10" ,
                "multiple_choice_base_skill_11" ,
                "multiple_choice_base_skill_12" ,
                "multiple_choice_base_skill_13" ,
                "multiple_choice_base_skill_14" ,
                "multiple_choice_base_skill_15" 
            }

            --Выбор базогого навака 
            MenuHelper:AddMultipleChoice({
				id = "multiple_choice_base",
				title = "multiple_choice_base_skill_title",
				desc = "multiple_choice_base_skill_desc",
				callback = "callback_multiple_choice_base",
				items = to_add,
				value = FG_Rebalance_mod._settings.Base_skill,
				menu_id = "FG_menu",
				priority = 7,
				localized = true
			})
            
            --Кнопка Fun_mode
            MenuHelper:AddToggle({
                id = "toggle_fun_mode",
                title = "toggle_fun_mode_title",
                desc = "toggle_fun_mode_desc",
                callback = "callback_toggle_fun_mode",
                value = FG_Rebalance_mod._settings.Fun_mode,
                menu_id = "FG_menu",
                priority = 6,
                localized = true
            })

        end)
    end)
end

--==[Баланс оружия]==--
if RequiredScript == "lib/tweak_data/weapontweakdata" then
    Hooks:PostHook(WeaponTweakData, "init", "WeaponTweakData_FG_Rebalance_mod", function(self)

        --Izmash Saiga-12K
        self.saiga.stats.damage = 240
        self.saiga.can_shoot_through_shield = true
        self.saiga.AMMO_PICKUP = {7, 7}
        self.saiga.timers.unequip = 0.1
        self.saiga.timers.equip = 0.1
        
        --Mosin-Nagant M1907
        self.mosin.stats.damage = 1000
        self.mosin.can_shoot_through_shield = true
        self.mosin.AMMO_PICKUP = {7, 7}
        self.mosin.timers.unequip = 0.1
        self.mosin.timers.equip = 0.1
        self.mosin.stats.concealment = 50

        --Fun mode
        if FG_Rebalance_mod._settings.Fun_mode == true then
            self.m134.CLIP_AMMO_MAX = 1000
            self.m134.NR_CLIPS_MAX = 2
            self.m134.AMMO_MAX = self.m134.CLIP_AMMO_MAX * self.m134.NR_CLIPS_MAX
            self.m134.AMMO_PICKUP = {100,100}
            self.m134.can_shoot_through_shield = true
            self.m134.stats.damage = 99999
            self.m134.stats.concealment = 50
            self.m134.timers = {
                reload_not_empty = 1,
                reload_empty = 1,
                unequip = 0.1,
                equip = 0.1
            }
        end
    end)
end

--==[Баланс дерева навыков]==--
if RequiredScript == "lib/tweak_data/skilltreetweakdata" then
    Hooks:PostHook(SkillTreeTweakData, "init", "SkillTreeTweakData_FG_Rebalance_mod", function(self, tweak_settings)
       
        self.skill_pages_order = {
            "mastermind",
            "enforcer",
            "technician",
            "ghost",
            "hoxton",
            "FG_New_Prek_Deck"
        }

        --Танцующий со Смертью
        self.skills.FG_New_Prek_Deck_1_11 = {
            ["name_id"] = "FG_New_Prek_Deck_1_11_name",
			["desc_id"] = "FG_New_Prek_Deck_1_11_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "smoke_screen_grenade",
                    "player_dodge_shot_gain",
                    "player_passive_dodge_chance_2", 
                    "player_kill_change_regenerate_speed",
                    "player_dodge_replenish_armor", 
                    "player_damage_to_hot_1", 
                    "player_damage_to_hot_extra_ticks",
                    "player_smoke_screen_ally_dodge_bonus", 
                    "player_sicario_multiplier", 
                    "weapon_passive_swap_speed_multiplier_1", 
                    "akimbo_recoil_index_addend_4",
                    "akimbo_extra_ammo_multiplier_3"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }
        --Fun Перк
        self.skills.FG_New_Prek_Deck_1_12 = {
            ["name_id"] = "FG_New_Prek_Deck_1_12_name",
			["desc_id"] = "FG_New_Prek_Deck_1_12_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "temporary_revive_damage_reduction_1",
                    "player_revive_damage_reduction_1",
                    "player_revive_health_boost",
                    "first_aid_kit_deploy_time_multiplier",
                    "first_aid_kit_damage_reduction_upgrade",
                    "player_revive_damage_reduction_level_1",
                    "player_revive_damage_reduction_level_2",
                    "first_aid_kit_quantity_increase_1",
                    "first_aid_kit_quantity_increase_2",
                    "first_aid_kit_auto_recovery_1",
                    "doctor_bag_quantity",
                    "doctor_bag_amount_increase1",
                    "player_revive_interaction_speed_multiplier",
                    "player_morale_boost",
                    "cooldown_long_dis_revive",
                    "cable_tie_quantity",
                    "cable_tie_interact_speed_multiplier",
                    "team_damage_hostage_absorption",
                    "player_intimidate_range_mul",
                    "player_intimidate_aura",
                    "player_civ_intimidation_mul",
                    "player_convert_enemies_max_minions_2",
                    "player_convert_enemies_damage_multiplier_1",
                    "player_convert_enemies",
                    "player_convert_enemies_max_minions_1",
                    "player_convert_enemies_damage_multiplier_2",
                    "player_convert_enemies_interaction_speed_multiplier",
                    "player_civ_calming_alerts",
                    "player_super_syndrome_1",
                    "player_minion_master_speed_multiplier",
                    "player_passive_convert_enemies_health_multiplier_1",
                    "player_minion_master_health_multiplier",
                    "player_passive_convert_enemies_health_multiplier_2",
                    "player_hostage_health_regen_addend_1",
                    "player_hostage_health_regen_addend_2",
                    "player_stability_increase_bonus_1",
                    "player_not_moving_accuracy_increase_bonus_1",
                    "weapon_enter_steelsight_speed_multiplier",
                    "player_steelsight_normal_movement_speed",
                    "assault_rifle_zoom_increase",
                    "snp_zoom_increase",
                    "smg_zoom_increase",
                    "lmg_zoom_increase",
                    "pistol_zoom_increase",
                    "assault_rifle_move_spread_index_addend",
                    "snp_move_spread_index_addend",
                    "smg_move_spread_index_addend",
                    "weapon_single_spread_index_addend",
                    "single_shot_accuracy_inc_1",
                    "head_shot_ammo_return_1",
                    "head_shot_ammo_return_2",
                    "assault_rifle_reload_speed_multiplier",
                    "smg_reload_speed_multiplier",
                    "snp_reload_speed_multiplier",
                    "temporary_single_shot_fast_reload_1",
                    "snp_graze_damage_1",
                    "snp_graze_damage_2",
                    "player_damage_multiplier_outnumbered",
                    "player_damage_dampener_outnumbered",
                    "shotgun_reload_speed_multiplier_1",
                    "shotgun_enter_steelsight_speed_multiplier",
                    "shotgun_reload_speed_multiplier_2",
                    "shotgun_recoil_index_addend",
                    "shotgun_damage_multiplier_1",
                    "shotgun_damage_multiplier_2",
                    "shotgun_steelsight_accuracy_inc_1",
                    "shotgun_steelsight_range_inc_1",
                    "shotgun_hip_run_and_shoot_1",
                    "shotgun_hip_rate_of_fire_1",
                    "shotgun_magazine_capacity_inc_1",
                    "player_overkill_damage_multiplier",
                    "player_overkill_all_weapons",
                    "weapon_swap_speed_multiplier",
                    "player_armor_regen_time_mul_1",
                    "player_flashbang_multiplier_1",
                    "player_flashbang_multiplier_2",
                    "player_interacting_damage_multiplier",
                    "player_level_2_armor_addend",
                    "player_level_3_armor_addend",
                    "player_level_4_armor_addend",
                    "carry_throw_distance_multiplier",
                    "player_armor_carry_bonus_1",
                    "team_armor_regen_time_multiplier",
                    "player_shield_knock",
                    "player_headshot_regen_armor_bonus_1",
                    "player_headshot_regen_armor_bonus_2",
                    "player_armor_multiplier",
                    "body_armor6",
                    "player_increased_pickup_area_1",
                    "player_double_drop_1",
                    "temporary_no_ammo_cost_1",
                    "temporary_no_ammo_cost_2",
                    "saw_secondary",
                    "saw_extra_ammo_multiplier",
                    "player_saw_speed_multiplier_2",
                    "saw_lock_damage_multiplier_2",
                    "ammo_bag_quantity",
                    "ammo_bag_ammo_increase1",
                    "saw_enemy_slicer",
                    "saw_ignore_shields_1",
                    "saw_panic_when_kill_1",
                    "extra_ammo_multiplier1",
                    "player_pick_up_ammo_multiplier",
                    "player_pick_up_ammo_multiplier_2",
                    "player_regain_throwable_from_ammo_1",
                    "sentry_gun_cost_reduction_1",
                    "sentry_gun_shield",
                    "sentry_gun_spread_multiplier",
                    "sentry_gun_rot_speed_multiplier",
                    "sentry_gun_extra_ammo_multiplier_1",
                    "sentry_gun_cost_reduction_2",
                    "sentry_gun_armor_multiplier",
                    "sentry_gun_silent",
                    "sentry_gun_ap_bullets",
                    "sentry_gun_fire_rate_reduction_1",
                    "deploy_interact_faster_1",
                    "second_deployable_1",
                    "sentry_gun_quantity_1",
                    "sentry_gun_quantity_2",
                    "player_drill_fix_interaction_speed_multiplier",
                    "player_trip_mine_deploy_time_multiplier_2",
                    "player_drill_alert",
                    "player_silent_drill",
                    "player_drill_autorepair_1",
                    "trip_mine_explosion_size_multiplier_1",
                    "trip_mine_damage_multiplier_1",
                    "player_drill_speed_multiplier1",
                    "player_drill_speed_multiplier2",
                    "shape_charge_quantity_increase_1",
                    "trip_mine_quantity_increase_1",
                    "shape_charge_quantity_increase_2",
                    "trip_mine_quantity_increase_2",
                    "player_drill_autorepair_2",
                    "player_drill_melee_hit_restart_chance_1",
                    "trip_mine_fire_trap_1",
                    "trip_mine_fire_trap_2",
                    "player_weapon_accuracy_increase_1",
                    "player_stability_increase_bonus_2",
                    "weapon_knock_down_1",
                    "weapon_knock_down_2",
                    "player_hip_fire_accuracy_inc_1",
                    "player_weapon_movement_stability_1",
                    "player_run_and_shoot_1",
                    "player_automatic_faster_reload_1",
                    "player_automatic_mag_increase_1",
                    "player_ap_bullets_1",
                    "weapon_automatic_head_shot_add_1",
                    "weapon_automatic_head_shot_add_2",
                    "player_suspicion_bonus",
                    "player_sec_camera_highlight_mask_off",
                    "player_special_enemy_highlight_mask_off",
                    "player_mask_off_pickup",
                    "player_small_loot_multiplier_1",
                    "player_corpse_dispose_amount_2",
                    "player_extra_corpse_dispose_amount",
                    "bodybags_bag_quantity",
                    "player_standstill_omniscience",
                    "player_buy_bodybags_asset",
                    "player_additional_assets",
                    "player_cleaner_cost_multiplier",
                    "player_buy_spotter_asset",
                    "player_tape_loop_duration_1",
                    "player_tape_loop_duration_2",
                    "player_pick_lock_hard",
                    "player_pick_lock_easy_speed_multiplier",
                    "ecm_jammer_duration_multiplier",
                    "ecm_jammer_feedback_duration_boost",
                    "ecm_jammer_can_open_sec_doors",
                    "ecm_jammer_quantity_increase_1",
                    "ecm_jammer_duration_multiplier_2",
                    "ecm_jammer_feedback_duration_boost_2",
                    "ecm_jammer_affects_pagers",
                    "player_stamina_regen_timer_multiplier",
                    "player_stamina_regen_multiplier",
                    "player_run_speed_multiplier",
                    "player_run_dodge_chance",
                    "player_movement_speed_multiplier",
                    "player_climb_speed_multiplier_1",
                    "player_can_free_run",
                    "player_run_and_reload",
                    "player_melee_concealment_modifier",
                    "player_ballistic_vest_concealment_1",
                    "player_armor_depleted_stagger_shot_1",
                    "player_armor_depleted_stagger_shot_2",
                    "player_taser_malfunction",
                    "player_taser_self_shock",
                    "player_escape_taser_1",
                    "player_detection_risk_add_dodge_chance_1",
                    "player_detection_risk_add_dodge_chance_2",
                    "temporary_damage_speed_multiplier",
                    "player_camouflage_bonus_1",
                    "player_camouflage_bonus_2",
                    "player_silencer_concealment_penalty_decrease_1",
                    "player_silencer_concealment_increase_1",
                    "weapon_silencer_recoil_index_addend",
                    "weapon_silencer_enter_steelsight_speed_multiplier",
                    "weapon_silencer_spread_index_addend",
                    "player_detection_risk_add_crit_chance_1",
                    "player_detection_risk_add_crit_chance_2",
                    "player_marked_enemy_extra_damage",
                    "player_marked_inc_dmg_distance_1",
                    "weapon_steelsight_highlight_specials",
                    "player_mark_enemy_time_multiplier",
                    "player_marked_distance_mul",
                    "player_unseen_increased_crit_chance_1",
                    "player_unseen_temp_increased_crit_chance_1",
                    "player_unseen_increased_crit_chance_2",
                    "player_unseen_temp_increased_crit_chance_2",
                    "pistol_swap_speed_multiplier",
                    "pistol_spread_index_addend",
                    "pistol_magazine_capacity_inc_1",
                    "pistol_fire_rate_multiplier",
                    "akimbo_recoil_index_addend_2",
                    "akimbo_extra_ammo_multiplier_1",
                    "akimbo_recoil_index_addend_3",
                    "pistol_damage_addend_1",
                    "pistol_damage_addend_2",
                    "pistol_stacked_accuracy_bonus_1",
                    "pistol_reload_speed_multiplier",
                    "pistol_stacking_hit_damage_multiplier_1",
                    "pistol_stacking_hit_damage_multiplier_2",
                    "player_bleed_out_health_multiplier",
                    "player_additional_lives_1",
                    "player_temp_swap_weapon_faster_1",
                    "player_temp_reload_weapon_faster_1",
                    "player_temp_increased_movement_speed_1",
                    "player_revived_damage_resist_1",
                    "player_revived_health_regain_1",
                    "temporary_berserker_damage_multiplier_1",
                    "temporary_berserker_damage_multiplier_2",
                    "player_berserker_no_ammo_cost",
                    "player_cheat_death_chance_1",
                    "player_cheat_death_chance_2",
                    "player_messiah_revive_from_bleed_out_1",
                    "player_recharge_messiah_1",
                    "player_melee_damage_dampener",
                    "player_melee_knockdown_mul",
                    "player_melee_damage_stacking_1",
                    "player_temp_melee_kill_increase_reload_speed_1",
                    "player_non_special_melee_multiplier",
                    "player_melee_damage_multiplier",
                    "player_counter_strike_melee",
                    "player_counter_strike_spooc",
                    "player_melee_damage_health_ratio_multiplier",
                    "player_damage_health_ratio_multiplier",
                    "player_healing_reduction_1",
                    "player_health_damage_reduction_1",
                    "player_max_health_reduction_1",
                    "player_healing_reduction_2",
                    "player_health_damage_reduction_2"
                    "player_health_damage_reduction_3"
                },
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }
        --
        self.skills.FG_New_Prek_Deck_1_13 = {
            ["name_id"] = "FG_New_Prek_Deck_1_13_name",
			["desc_id"] = "FG_New_Prek_Deck_1_13_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }

        self.skills.FG_New_Prek_Deck_1_21 = {
            ["name_id"] = "FG_New_Prek_Deck_1_21_name",
			["desc_id"] = "FG_New_Prek_Deck_1_21_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }

        self.skills.FG_New_Prek_Deck_1_31 = {
            ["name_id"] = "FG_New_Prek_Deck_1_31_name",
			["desc_id"] = "FG_New_Prek_Deck_1_31_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }

        self.skills.FG_New_Prek_Deck_1_41 = {
            ["name_id"] = "FG_New_Prek_Deck_1_31_name",
			["desc_id"] = "FG_New_Prek_Deck_1_31_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }
        --
        self.skills.FG_New_Prek_Deck_2_11 = {
            ["name_id"] = "FG_New_Prek_Deck_2_11_name",
			["desc_id"] = "FG_New_Prek_Deck_2_11_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }
        --
        self.skills.FG_New_Prek_Deck_2_12 = {
            ["name_id"] = "FG_New_Prek_Deck_2_12_name",
			["desc_id"] = "FG_New_Prek_Deck_2_12_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }
        --
        self.skills.FG_New_Prek_Deck_2_13 = {
            ["name_id"] = "FG_New_Prek_Deck_2_13_name",
			["desc_id"] = "FG_New_Prek_Deck_2_13_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }

        self.skills.FG_New_Prek_Deck_2_21 = {
            ["name_id"] = "FG_New_Prek_Deck_1_21_name",
			["desc_id"] = "FG_New_Prek_Deck_1_21_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }

        self.skills.FG_New_Prek_Deck_2_31 = {
            ["name_id"] = "FG_New_Prek_Deck_1_21_name",
			["desc_id"] = "FG_New_Prek_Deck_1_21_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }

        self.skills.FG_New_Prek_Deck_2_41 = {
            ["name_id"] = "FG_New_Prek_Deck_1_21_name",
			["desc_id"] = "FG_New_Prek_Deck_1_21_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }
        --
        self.skills.FG_New_Prek_Deck_3_11 = {
            ["name_id"] = "FG_New_Prek_Deck_3_11_name",
			["desc_id"] = "FG_New_Prek_Deck_3_11_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }
        --
        self.skills.FG_New_Prek_Deck_3_12 = {
            ["name_id"] = "FG_New_Prek_Deck_3_12_name",
			["desc_id"] = "FG_New_Prek_Deck_3_12_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
				
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
  
				},
				cost = self.costs.unlock_tree
			}
        }
        --
        self.skills.FG_New_Prek_Deck_3_13 = {
            ["name_id"] = "FG_New_Prek_Deck_3_13_name",
			["desc_id"] = "FG_New_Prek_Deck_3_13_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
					
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
    
				},
				cost = self.costs.unlock_tree
			}

        }
    
        self.skills.FG_New_Prek_Deck_3_21 = {
            ["name_id"] = "FG_New_Prek_Deck_3_11_name",
			["desc_id"] = "FG_New_Prek_Deck_3_11_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }

        self.skills.FG_New_Prek_Deck_3_31 = {
            ["name_id"] = "FG_New_Prek_Deck_3_11_name",
			["desc_id"] = "FG_New_Prek_Deck_3_11_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }

        self.skills.FG_New_Prek_Deck_3_41 = {
            ["name_id"] = "FG_New_Prek_Deck_3_11_name",
			["desc_id"] = "FG_New_Prek_Deck_3_11_desc",
			["icon_xy"] = {7, 10},
			[1] = {
				upgrades = {
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			},
			[2] = {
				upgrades = { 
                    "player_damage_to_hot_1"
				},
				cost = self.costs.unlock_tree
			}
        }

        table.insert(self.trees,{
			name_id = "FG_New_Prek_Deck_tree_1",
			background_texture = "guis/textures/pd2/skilltree/bg_subordinate",
			unlocked = true,
			skill = "FG_New_Prek_Deck",
			tiers = {
				{	
                    "FG_New_Prek_Deck_1_11",
                    "FG_New_Prek_Deck_1_12",
                    "FG_New_Prek_Deck_1_13"
				},
				{
                    "FG_New_Prek_Deck_1_21"
				},
				{
                    "FG_New_Prek_Deck_1_31"
				},
				{
                    "FG_New_Prek_Deck_1_41"
                }
			}
        })
    
        table.insert(self.trees,{
			name_id = "FG_New_Prek_Deck_tree_2",
			background_texture = "guis/textures/pd2/skilltree/bg_subordinate",
			unlocked = true,
			skill = "FG_New_Prek_Deck",
			tiers = {
				{	
                    "FG_New_Prek_Deck_2_11",
                    "FG_New_Prek_Deck_2_12",
                    "FG_New_Prek_Deck_2_13"
				},
				{
                    "FG_New_Prek_Deck_2_21"
				},
				{
                    "FG_New_Prek_Deck_2_31"
				},
				{
                    "FG_New_Prek_Deck_2_41"
                }
			}
        })	
        
        table.insert(self.trees,{
			name_id = "FG_New_Prek_Deck_tree_3",
			background_texture = "guis/textures/pd2/skilltree/bg_subordinate",
			unlocked = true,
			skill = "FG_New_Prek_Deck",
			tiers = {
				{	
                    "FG_New_Prek_Deck_3_11",
                    "FG_New_Prek_Deck_3_12",
                    "FG_New_Prek_Deck_3_13"
				},
				{
                    "FG_New_Prek_Deck_3_21"
				},
				{
                    "FG_New_Prek_Deck_3_31"
				},
				{
                    "FG_New_Prek_Deck_3_41"
                }
			}
		})		
        

        self.skilltree.FG_New_Prek_Deck = {
            name_id = "FG_New_Prek_Deck_title",
            desc_id = "FG_New_Prek_Deck_desc"
        
        }

        if FG_Rebalance_mod._settings.Fun_mode == true then 
            self.skills.frenzy[1].upgrades = {
                "smoke_screen_grenade"
            }
        else 
            self.skills.frenzy[1].upgrades = {
                "player_max_health_reduction_1",
                "player_healing_reduction_2",
                "player_health_damage_reduction_3",
                
            }
        end

        table.insert(self.default_upgrades, "player_health_damage_reduction_3")
    

        self.skills.frenzy[2].upgrades = {
            "player_healing_reduction_2", 
            "player_damage_dampener_close_contact_1"
        }
        
    end)
end

--==[Улучшение навыков]==--
if RequiredScript == "lib/tweak_data/upgradestweakdata" then
    Hooks:PostHook(UpgradesTweakData, "init", "UpgradesTweakData_FG_Rebalance_mod", function(self)
	
        self.values.player.health_damage_reduction = {
            0.9,
            0.75,
            0.3,
            0
        }
        self.definitions.player_health_damage_reduction_3 = {
            name_id = "menu_player_health_damage_reduction",
            category = "feature",
            upgrade = {
                value = 3,
                upgrade = "health_damage_reduction",
                category = "player"
            }
        }
    
    end)
end

--==[]==--

--==[]==--

--==[]==--

--==[]==--